import { Text, SafeAreaView, StyleSheet, FlatList } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import Item from './components/Item';
import AssetExample from './components/AssetExample';


const data = [{"id":1,"title":"Samsung","shop_name":"Finance","image":"http://dummyimage.com/233x100.png/dddddd/000000"},
{"id":2,"title":"Motorola","shop_name":"n/a","image":"http://dummyimage.com/163x100.png/dddddd/000000"},
{"id":3,"title":"Benefon","shop_name":"Finance","image":"http://dummyimage.com/209x100.png/dddddd/000000"},
{"id":4,"title":"Panasonic","shop_name":"n/a","image":"http://dummyimage.com/212x100.png/5fa2dd/ffffff"},
{"id":5,"title":"Lenovo","shop_name":"Basic Industries","image":"http://dummyimage.com/203x100.png/dddddd/000000"},
{"id":6,"title":"vivo","shop_name":"Consumer Services","image":"http://dummyimage.com/181x100.png/5fa2dd/ffffff"},
{"id":7,"title":"Samsung","shop_name":"Capital Goods","image":"http://dummyimage.com/225x100.png/ff4444/ffffff"},
{"id":8,"title":"Orange","shop_name":"n/a","image":"http://dummyimage.com/130x100.png/dddddd/000000"},
{"id":9,"title":"Archos","shop_name":"Public Utilities","image":"http://dummyimage.com/140x100.png/cc0000/ffffff"},
{"id":10,"title":"alcatel","shop_name":"n/a","image":"http://dummyimage.com/161x100.png/5fa2dd/ffffff"},
{"id":11,"title":"Samsung","shop_name":"Public Utilities","image":"http://dummyimage.com/116x100.png/5fa2dd/ffffff"},
{"id":12,"title":"Intex","shop_name":"Public Utilities","image":"http://dummyimage.com/237x100.png/cc0000/ffffff"},
{"id":13,"title":"BLU","shop_name":"Health Care","image":"http://dummyimage.com/183x100.png/dddddd/000000"},
{"id":14,"title":"Sendo","shop_name":"Capital Goods","image":"http://dummyimage.com/237x100.png/5fa2dd/ffffff"},
{"id":15,"title":"Samsung","shop_name":"Health Care","image":"http://dummyimage.com/246x100.png/ff4444/ffffff"},
{"id":16,"title":"Xiaomi","shop_name":"Capital Goods","image":"http://dummyimage.com/233x100.png/5fa2dd/ffffff"},
{"id":17,"title":"Allview","shop_name":"Consumer Services","image":"http://dummyimage.com/137x100.png/ff4444/ffffff"},
{"id":18,"title":"Samsung","shop_name":"Public Utilities","image":"http://dummyimage.com/107x100.png/dddddd/000000"},
{"id":19,"title":"Samsung","shop_name":"Health Care","image":"http://dummyimage.com/183x100.png/ff4444/ffffff"},
{"id":20,"title":"HP","shop_name":"Consumer Durables","image":"http://dummyimage.com/187x100.png/ff4444/ffffff"},
{"id":21,"title":"Philips","shop_name":"Technology","image":"http://dummyimage.com/187x100.png/cc0000/ffffff"},
{"id":22,"title":"Bird","shop_name":"Technology","image":"http://dummyimage.com/115x100.png/dddddd/000000"},
{"id":23,"title":"Ericsson","shop_name":"Finance","image":"http://dummyimage.com/242x100.png/dddddd/000000"},
{"id":24,"title":"LG","shop_name":"Finance","image":"http://dummyimage.com/237x100.png/cc0000/ffffff"},
{"id":25,"title":"Yezz","shop_name":"Finance","image":"http://dummyimage.com/200x100.png/dddddd/000000"},
{"id":26,"title":"Yezz","shop_name":"n/a","image":"http://dummyimage.com/153x100.png/ff4444/ffffff"},
{"id":27,"title":"Tecno","shop_name":"Technology","image":"http://dummyimage.com/177x100.png/ff4444/ffffff"}]

export default function App() {
  return (
  
    <FlatList
        data={data}
        renderItem={({item}) => <Item data = {item} />}
        keyExtractor={item => item.id}
      />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
