import {View, Image, Text, StyleSheet, TouchableOpacity} from 'react-native'

export default function Item({data}){
 
  return (
      <View style = {{  justifyContent: 'center', flexDirection: 'row', alignItems: 'center', padding: 5}}>  
        <View style= {{flex: 1}}> 
          <Image
            style={{width: '100%', height: 90}}
            source={{
            uri: data.image,
          }}
        />
        </View>
        <View style= {{flex: 2, alignSelf: 'flex-start', justifyContent: 'flex-start'}}>
          <Text style = {{fontSize: 15}}> {data.title}</Text>
          <Text> Shop: {data.shop_name}</Text>
        </View>
        <View style= {{flex: 1}}> 
          <TouchableOpacity style = {{backgroundColor: 'red', width: 80, padding: 10}}>
            Chat
          </TouchableOpacity>
        </View> 
  
  </View>
  )

  
}

const styles = StyleSheet.create({
 
});